#svn update;
latex CC-P0D-TPC-Analysis.tex;
dvipdf CC-P0D-TPC-Analysis.dvi;
#pdflatex CC-P0D-TPC-Analysis.tex
cp CC-P0D-TPC-Analysis.pdf ~/public_html/./
